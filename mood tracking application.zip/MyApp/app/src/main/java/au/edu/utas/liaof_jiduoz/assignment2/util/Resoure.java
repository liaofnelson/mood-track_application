package au.edu.utas.liaof_jiduoz.assignment2.util;


import au.edu.utas.liaof_jiduoz.assignment2.R;

public class Resoure {

    //Some static values
    public static final int image_id[]={
            R.id.add_ImageButton1,
            R.id.add_ImageButton2,
            R.id.add_ImageButton3,
            R.id.add_ImageButton4,
            R.id.add_ImageButton5,
            R.id.add_ImageButton6,
            R.id.add_ImageButton7,
            R.id.add_ImageButton8
    };
    public static final String mood[]= {
            "amazing",
            "happy",
            "sad",
            "smile",
            "funny",
            "no_sense",
            "exciting",
            "grievances"
    };
    public static final int image1[]={
            R.drawable.amazing,
            R.drawable.happy,
            R.drawable.sad,
            R.drawable.smile,
            R.drawable.funny,
            R.drawable.no_sense,
            R.drawable.exciting,
            R.drawable.grievances
    };
    public static final int image2[]={
            R.drawable.amazing_onclick,
            R.drawable.happy_onclick,
            R.drawable.sad_onclick,
            R.drawable.smile_onclick,
            R.drawable.funny_onclick,
            R.drawable.no_onclick,
            R.drawable.exciting_onclick,
            R.drawable.weiqu_oncllick
    };

    public static final String table_info[]= {

            "title_str",
            "mood_src",
            "topic_text",
            "entries_text",
            "date",
            "location"

    };
}
