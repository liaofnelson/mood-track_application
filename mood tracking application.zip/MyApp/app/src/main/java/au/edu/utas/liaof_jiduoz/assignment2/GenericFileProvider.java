package au.edu.utas.liaof_jiduoz.assignment2;

import android.support.v4.content.FileProvider;

//IO interface
public class GenericFileProvider extends FileProvider {

}
